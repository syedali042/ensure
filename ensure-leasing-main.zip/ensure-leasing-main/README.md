# **Ensure Leasing Application**

A React and Node JS app to serve the API and dashboard for Ensure Leasing.
