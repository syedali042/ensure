const GlobalValues = {
  CodeCategories: {
    stilstand: {
      db: 'Stilstand',
      app: 'stilstand',
    },
    glasdakning: {
      db: 'Glasdækning',
      app: 'glasdakning',
    },
    withoutglass: {
      db: 'Glasdækning',
      app: 'withoutglass',
    },
  },
};

export default GlobalValues;
