const add = require('./add');
const get = require('./get');
const remove = require('./remove');
const update = require('./update');
module.exports = {
  add,
  get,
  remove,
  update,
};
