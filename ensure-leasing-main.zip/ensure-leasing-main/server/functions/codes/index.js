const add = require('./add');
const get = require('./get');
module.exports = {
  add,
  get,
};
