const uploadFileFromBuffer = require('./uploadFileFromBuffer');
module.exports = {
  uploadFileFromBuffer,
};
