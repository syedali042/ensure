const get = require('./get');
const update = require('./update');
module.exports = {
  get,
  update,
};
