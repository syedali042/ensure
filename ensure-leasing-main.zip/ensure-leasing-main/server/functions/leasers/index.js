const get = require('./get');
const add = require('./add');
const update = require('./update');
module.exports = {
  get,
  add,
  update,
};
