module.exports = {
  failureNotificationWebhook:
    'https://hook.integromat.com/q9khhkp7araervy94qe80xs2uwk4xuwo',
};
