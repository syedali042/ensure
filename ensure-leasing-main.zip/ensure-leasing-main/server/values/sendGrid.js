module.exports.sendingName = 'Ensure';
module.exports.sendingEmailAddress = 'Noreply@ensure-leasing.dk';
module.exports.entryEmailTemplateId = 'd-6f16b07b32c04a038549ad934f78c27d';
module.exports.leaserEmailTemplateId = 'd-b7680f0e3e3040c3a6d683a07c2dc25b';
